extends Node2D

# Runtime ports of the TD CoinScene mechanics. Each packaged scene selects one
# source mechanic while retaining the same source-textured token board.
@export_enum("wave", "shower", "bomb", "jumbo", "walls") var mechanic := "wave"
@export var mechanic_strength := 280.0
@export var shower_count := 7
@export var token_texture: Texture2D

const BOARD := Rect2(255.0, 116.0, 642.0, 430.0)
const COLLECTION_Y := 510.0
var tokens: Array[Dictionary] = []
var elapsed := 0.0
var auto_timer := 0.35
var wave_x := -1.0
var jumbo_y := 120.0
var jumbo_velocity := 0.0
var wall_phase := 0.0
var explosion_flash := 0.0
var collected := 0
var action_count := 0
var label: Label
var verification_press_sent := false
var verification_release_frames := 0
var mouse_was_pressed := false

func _ready() -> void:
	fit_to_viewport()
	create_hud()
	seed_tokens()
	queue_redraw()

func _process(delta: float) -> void:
	fit_to_viewport()
	elapsed += delta
	if "--verify-action" in OS.get_cmdline_user_args() and not verification_press_sent and elapsed >= 1.6:
		Input.action_press("ui_accept")
		verification_press_sent = true
		verification_release_frames = 2
	elif verification_release_frames > 0:
		verification_release_frames -= 1
		if verification_release_frames == 0:
			Input.action_release("ui_accept")
	auto_timer -= delta
	if auto_timer <= 0.0:
		trigger_mechanic("AUTO")
		auto_timer = 3.2
	var mouse_pressed := Input.is_mouse_button_pressed(MOUSE_BUTTON_LEFT)
	if Input.is_action_just_pressed("ui_accept") or (mouse_pressed and not mouse_was_pressed):
		trigger_mechanic("INPUT")
	mouse_was_pressed = mouse_pressed
	update_mechanic(delta)
	update_tokens(delta)
	if elapsed > 0.5 and fmod(elapsed, 1.0) < delta:
		var sample := Vector2.ZERO if tokens.is_empty() else (tokens[0].node as Sprite2D).position
		print("MOTION_SAMPLE mechanic=%s t=%.1f first=(%.1f,%.1f) collected=%d actions=%d" % [mechanic, elapsed, sample.x, sample.y, collected, action_count])
	label.text = "%s\n\nCollected: %d\nActions: %d\n\nSPACE / CLICK\ntrigger mechanic\n\nAutomatic preview\nruns every cycle." % [mechanic.to_upper(), collected, action_count]
	queue_redraw()

func fit_to_viewport() -> void:
	var viewport_size := get_viewport_rect().size
	var factor := minf(viewport_size.x / 1152.0, viewport_size.y / 648.0)
	scale = Vector2.ONE * factor
	position = (viewport_size - Vector2(1152.0, 648.0) * factor) * 0.5

func seed_tokens() -> void:
	for row in 3:
		for column in 5:
			spawn_token(Vector2(365.0 + column * 100.0 + (row % 2) * 24.0, 205.0 + row * 92.0), Vector2(0.0, 18.0 + row * 5.0))

func spawn_token(at: Vector2, velocity: Vector2) -> void:
	var token := Sprite2D.new()
	token.name = "SourceToken"
	token.texture = token_texture
	token.position = at
	token.scale = Vector2(0.78, 0.78)
	add_child(token)
	tokens.append({"node": token, "velocity": velocity})

func trigger_mechanic(origin: String) -> void:
	action_count += 1
	print("ACTION_TRANSITION mechanic=%s origin=%s count=%d" % [mechanic, origin, action_count])
	match mechanic:
		"wave":
			wave_x = BOARD.position.x
		"shower":
			for index in shower_count:
				spawn_token(Vector2(350.0 + index * (520.0 / maxf(shower_count - 1, 1)), 135.0 - (index % 2) * 28.0), Vector2(sin(index * 2.1) * 24.0, 115.0))
		"bomb":
			explosion_flash = 0.45
			var center := BOARD.get_center()
			for token in tokens:
				var node: Sprite2D = token.node
				var direction := (node.position - center).normalized()
				token.velocity = direction * mechanic_strength + Vector2(0.0, -mechanic_strength * 0.45)
		"jumbo":
			jumbo_y = BOARD.position.y - 35.0
			jumbo_velocity = 250.0
		"walls":
			wall_phase = 0.001

func update_mechanic(delta: float) -> void:
	if wave_x >= 0.0:
		wave_x += mechanic_strength * delta
		for token in tokens:
			var node: Sprite2D = token.node
			if node.position.x < wave_x + 28.0:
				token.velocity.y = maxf(token.velocity.y, mechanic_strength * 0.82)
		if wave_x > BOARD.end.x + 35.0:
			wave_x = -1.0
	if jumbo_velocity > 0.0:
		jumbo_y += jumbo_velocity * delta
		jumbo_velocity += 420.0 * delta
		if jumbo_y >= 352.0:
			jumbo_y = 352.0
			jumbo_velocity = 0.0
			for token in tokens:
				var node: Sprite2D = token.node
				var horizontal := signf(node.position.x - BOARD.get_center().x)
				token.velocity = Vector2(horizontal * mechanic_strength * 0.45, mechanic_strength)
	if wall_phase > 0.0:
		wall_phase += delta * 0.55
		if wall_phase >= 2.0:
			wall_phase = 0.0
	explosion_flash = maxf(0.0, explosion_flash - delta)

func update_tokens(delta: float) -> void:
	for token in tokens.duplicate():
		var node: Sprite2D = token.node
		var velocity: Vector2 = token.velocity
		velocity.y += 38.0 * delta
		node.position += velocity * delta
		node.rotation += velocity.length() * delta * 0.004
		if node.position.x < BOARD.position.x + 18.0 or node.position.x > BOARD.end.x - 18.0:
			velocity.x *= -0.72
			node.position.x = clampf(node.position.x, BOARD.position.x + 18.0, BOARD.end.x - 18.0)
		if node.position.y < BOARD.position.y + 18.0:
			velocity.y = absf(velocity.y) * 0.72
			node.position.y = BOARD.position.y + 18.0
		token.velocity = velocity
		if node.position.y > COLLECTION_Y:
			collected += 1
			node.queue_free()
			tokens.erase(token)
	if tokens.size() < 8:
		seed_tokens()

func create_hud() -> void:
	label = Label.new()
	label.position = Vector2(32.0, 165.0)
	label.size = Vector2(195.0, 280.0)
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_font_size_override("font_size", 20)
	label.add_theme_color_override("font_color", Color("f9edca"))
	add_child(label)

func wall_height() -> float:
	if wall_phase <= 0.0:
		return 0.0
	var progress := wall_phase if wall_phase <= 1.0 else 2.0 - wall_phase
	return clampf(progress, 0.0, 1.0) * mechanic_strength

func _draw() -> void:
	draw_rect(Rect2(Vector2.ZERO, Vector2(1152.0, 648.0)), Color("101922"))
	draw_string(ThemeDB.fallback_font, Vector2(285.0, 58.0), "TD 2D  •  %s" % mechanic.to_upper(), HORIZONTAL_ALIGNMENT_LEFT, -1, 27, Color("ffe5a4"))
	draw_rect(BOARD, Color("263d57"))
	draw_rect(BOARD, Color("7998b7"), false, 4.0)
	for y in [210.0, 310.0, 410.0]:
		draw_line(Vector2(BOARD.position.x, y), Vector2(BOARD.end.x, y), Color("3e6081"), 2.0)
	draw_rect(Rect2(BOARD.position.x, COLLECTION_Y, BOARD.size.x, BOARD.end.y - COLLECTION_Y), Color("e3b255"))
	draw_string(ThemeDB.fallback_font, Vector2(680.0, 536.0), "COLLECT", HORIZONTAL_ALIGNMENT_LEFT, -1, 18, Color.WHITE)
	if wave_x >= 0.0:
		draw_line(Vector2(wave_x, BOARD.position.y), Vector2(wave_x, BOARD.end.y), Color("8ae4ff"), 12.0)
	if jumbo_velocity > 0.0 or mechanic == "jumbo":
		draw_circle(Vector2(BOARD.get_center().x, jumbo_y), 34.0, Color("a7ed6f"))
	if explosion_flash > 0.0:
		draw_circle(BOARD.get_center(), 55.0 + (0.45 - explosion_flash) * mechanic_strength, Color(1.0, 0.42, 0.16, explosion_flash * 1.8), false, 12.0)
	var height := wall_height()
	if height > 0.0:
		draw_rect(Rect2(BOARD.position.x, BOARD.end.y - height, 38.0, height), Color("8bd1a1"))
		draw_rect(Rect2(BOARD.end.x - 38.0, BOARD.end.y - height, 38.0, height), Color("8bd1a1"))
